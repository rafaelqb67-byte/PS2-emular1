package com.seuapp.emuladorps2

import android.net.Uri
import android.os.Bundle
import android.view.MotionEvent
import android.view.SurfaceView
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private var biosUri: Uri? = null
    private var romUri: Uri? = null

    private val selectBiosLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            biosUri = it
            Toast.makeText(this, "BIOS selecionada!", Toast.LENGTH_SHORT).show()
        }
    }

    private val selectRomLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            romUri = it
            Toast.makeText(this, "Jogo selecionado!", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnSelectBios = findViewById<Button>(R.id.btnSelectBios)
        val btnSelectRom = findViewById<Button>(R.id.btnSelectRom)
        val btnPlay = findViewById<Button>(R.id.btnPlay)
        val menuLayout = findViewById<LinearLayout>(R.id.menuLayout)
        val controlsOverlay = findViewById<RelativeLayout>(R.id.controlsOverlay)
        val gameSurface = findViewById<SurfaceView>(R.id.gameSurface)

        btnSelectBios.setOnClickListener {
            selectBiosLauncher.launch(arrayOf("*/*"))
        }

        btnSelectRom.setOnClickListener {
            selectRomLauncher.launch(arrayOf("*/*"))
        }

        btnPlay.setOnClickListener {
            if (biosUri == null || romUri == null) {
                Toast.makeText(this, "Selecione a BIOS e a ROM primeiro!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            menuLayout.visibility = View.GONE
            controlsOverlay.visibility = View.VISIBLE

            Toast.makeText(this, "Núcleo PS2 carregado! Iniciando...", Toast.LENGTH_SHORT).show()
        }

        val botoes = listOf(
            R.id.btnDpadUp to 1,
            R.id.btnDpadDown to 2,
            R.id.btnDpadLeft to 3,
            R.id.btnDpadRight to 4,
            R.id.btnCross to 5,
            R.id.btnCircle to 6,
            R.id.btnSquare to 7,
            R.id.btnTriangle to 8,
            R.id.btnL1 to 9,
            R.id.btnL2 to 10,
            R.id.btnR1 to 11,
            R.id.btnR2 to 12,
            R.id.btnSelect to 13,
            R.id.btnStart to 14
        )

        for ((id, codigo) in botoes) {
            findViewById<Button>(id).setOnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> { }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { }
                }
                true
            }
        }
    }

    companion object {
        init {
            System.loadLibrary("play_libretro_android")
        }
    }
}
